package com.tareq.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast

// find view by id
//kotlin extension
//Data binding

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


 val etEmail = findViewById<EditText>(R.id.etEmail)
 val etPassword = findViewById<EditText>(R.id.etPassword)
 val btnLogin = findViewById<Button>(R.id.btnLogin)
 val logo = findViewById<ImageView>(R.id.logo)

  logo.setOnClickListener {

      Toast.makeText(this, "this is the logo of sbtjapan", Toast.LENGTH_SHORT).show()
  }




        btnLogin.setOnClickListener {

            val email = etEmail.text.toString()
            val password = etPassword.text.toString()
            val profileActivityIntent = Intent(this@LoginActivity, ProfileActivity::class.java)
            profileActivityIntent.putExtra("added_email", email)
            profileActivityIntent.putExtra("added_password", password)

            startActivity(profileActivityIntent)
        }

    }
}
