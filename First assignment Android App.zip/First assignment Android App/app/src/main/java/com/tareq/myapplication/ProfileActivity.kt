package com.tareq.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)


        val email = intent.getStringExtra("added_email")
        val password = intent.getStringExtra("added_password")

        findViewById<TextView>(R.id.userEmail).text = email
        findViewById<TextView>(R.id.userPassword).text = password
    }
}